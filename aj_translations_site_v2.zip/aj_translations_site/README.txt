AJ TRANSLATIONS — SITE WEB POUR GITHUB PAGES

Contenu du dossier
- index.html : page d'accueil
- apropos.html : page À propos
- services.html : page Services
- contact.html : page Contact
- style.css : mise en forme commune

AVANT DE PUBLIER
1. Vérifiez que l'adresse e-mail et le numéro de téléphone dans contact.html sont corrects.
2. Vérifiez que le contenu correspond à votre activité réelle et modifiez toute information nécessaire.
3. Les images sont chargées depuis Unsplash et les polices depuis Google Fonts : une connexion Internet est nécessaire pour les afficher.

PUBLICATION SUR GITHUB PAGES
1. Ouvrez le dépôt GitHub existant.
2. Téléversez les quatre fichiers HTML, style.css et ce README.txt à la racine du dépôt.
3. Si les fichiers du dépôt portent déjà ces noms, confirmez leur remplacement après avoir conservé une copie de sauvegarde.
4. Dans Settings > Pages, sélectionnez la branche main et le dossier /(root), puis enregistrez.
5. Attendez la publication et testez le site ainsi que chaque lien de navigation.
6. Déposez l'URL publique du site sur Moodle.

REMARQUE
Le site est statique : le lien e-mail ouvre l'application de messagerie du visiteur. Il n'y a pas de formulaire avec envoi automatique.
